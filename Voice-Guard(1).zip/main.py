import torch
import os
import logging
from models.feature_extractor import FeatureExtractor
from models.psychoacoustic import PsychoacousticModel
from models.perturbation_generator import PerturbationGenerator
from models.voice_conversion import VoiceConversionModel
from utils.audio import AudioProcessor
from utils.evaluation import Evaluator
from config import *

# 配置日志
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

def main():
    # 初始化设备
    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    logger.info(f'使用设备: {device}')
    
    try:
        # 初始化模型和工具
        feature_extractor = FeatureExtractor().to(device)
        psychoacoustic_model = PsychoacousticModel().to(device)
        perturbation_generator = PerturbationGenerator().to(device)
        vc_model = VoiceConversionModel()
        audio_processor = AudioProcessor()
        evaluator = Evaluator()
        
        # 加载测试音频
        test_audio_dir = os.path.join(DATA_DIR, 'test_audio')
        if not os.path.exists(test_audio_dir):
            os.makedirs(test_audio_dir)
            logger.info(f'请将测试音频文件放在 {test_audio_dir} 目录下')
            return
            
        audio_files = [f for f in os.listdir(test_audio_dir) if f.endswith('.wav')]
        if not audio_files:
            logger.info('未找到测试音频文件')
            return
            
        logger.info(f'找到 {len(audio_files)} 个测试音频文件')
        
        # 处理每个音频文件
        for audio_file in audio_files:
            logger.info(f'\n处理音频: {audio_file}')
            
            try:
                # 加载音频
                audio_path = os.path.join(test_audio_dir, audio_file)
                waveform = audio_processor.load_audio(audio_path).to(device)
                
                # 提取原始特征
                original_features = feature_extractor(waveform)
                
                # 生成对抗扰动（完整模型）
                perturbed_audio_full, perturbation_full, _ = perturbation_generator.generate_perturbation(
                    waveform,
                    feature_extractor,
                    psychoacoustic_model,
                    vc_model
                )
                
                # 生成对抗扰动（不带心理声学模型）
                perturbed_audio_wo_p, perturbation_wo_p, _ = perturbation_generator.generate_perturbation(
                    waveform,
                    feature_extractor,
                    None,
                    vc_model
                )
                
                # 提取特征
                perturbed_features_full = feature_extractor(perturbed_audio_full)
                perturbed_features_wo_p = feature_extractor(perturbed_audio_wo_p)
                
                # 评估结果
                metrics_full = evaluator.evaluate(
                    waveform,
                    perturbed_audio_full,
                    original_features,
                    perturbed_features_full
                )
                
                metrics_wo_p = evaluator.evaluate(
                    waveform,
                    perturbed_audio_wo_p,
                    original_features,
                    perturbed_features_wo_p
                )
                
                # 保存音频文件
                output_dir = os.path.join(RESULTS_DIR, os.path.splitext(audio_file)[0])
                os.makedirs(output_dir, exist_ok=True)
                
                # 保存处理后的音频
                audio_processor.save_audio(
                    perturbed_audio_full,
                    os.path.join(output_dir, 'perturbed_audio.wav')
                )
                audio_processor.save_audio(
                    perturbation_full,
                    os.path.join(output_dir, 'perturbation.wav')
                )
                
                # 打印评估结果
                logger.info(f'\n完整模型评估结果:')
                for metric, value in metrics_full.items():
                    logger.info(f'{metric}: {value:.4f}')
                    
                logger.info(f'\n不带心理声学模型评估结果:')
                for metric, value in metrics_wo_p.items():
                    logger.info(f'{metric}: {value:.4f}')
                    
            except Exception as e:
                logger.error(f'处理音频 {audio_file} 时出错: {str(e)}')
                continue
        
        logger.info('\n处理完成！结果保存在 results 目录下')
        
    except Exception as e:
        logger.error(f'程序运行出错: {str(e)}')

if __name__ == '__main__':
    main() 