import torch
import torch.nn as nn
import torchaudio
import numpy as np
from config import *

class MelSpectrogram(nn.Module):
    def __init__(self):
        super().__init__()
        self.mel_spec = torchaudio.transforms.MelSpectrogram(
            sample_rate=SAMPLE_RATE,
            n_fft=N_FFT,
            hop_length=HOP_LENGTH,
            win_length=WIN_LENGTH,
            n_mels=N_MELS,
            center=True,
            power=2.0,
            norm='slaney',
            mel_scale='slaney'
        )
        
    def forward(self, x):
        # 确保输入是二维的 [batch_size, signal_length]
        if x.dim() == 1:
            x = x.unsqueeze(0)
        
        # 计算梅尔频谱图
        mel = self.mel_spec(x)
        
        # 转换为分贝刻度
        mel = torch.log10(torch.clamp(mel, min=1e-10))
        
        return mel

class FeatureExtractor(nn.Module):
    def __init__(self):
        super().__init__()
        self.mel_extractor = MelSpectrogram()
        
        # CNN特征提取器
        self.conv_layers = nn.Sequential(
            nn.Conv2d(1, 32, kernel_size=3, stride=1, padding=1),
            nn.ReLU(),
            nn.MaxPool2d(2, 2),
            nn.Conv2d(32, 64, kernel_size=3, stride=1, padding=1),
            nn.ReLU(),
            nn.MaxPool2d(2, 2),
            nn.Conv2d(64, 128, kernel_size=3, stride=1, padding=1),
            nn.ReLU(),
            nn.AdaptiveAvgPool2d((4, 4))  # 使用自适应池化替代固定大小的池化
        )
        
        # 全连接层
        self.fc_layers = nn.Sequential(
            nn.Linear(128 * 4 * 4, 512),
            nn.ReLU(),
            nn.Dropout(0.5),
            nn.Linear(512, FEATURE_DIM)
        )
        
    def forward(self, x):
        # 提取梅尔频谱特征
        mel = self.mel_extractor(x)
        
        # 添加通道维度
        mel = mel.unsqueeze(1)
        
        # CNN特征提取
        conv_out = self.conv_layers(mel)
        
        # 展平
        flat = conv_out.view(conv_out.size(0), -1)
        
        # 全连接层
        features = self.fc_layers(flat)
        
        return features

    def extract_features(self, audio_batch):
        """
        从音频批次中提取特征
        """
        self.eval()
        with torch.no_grad():
            features = self(audio_batch)
        return features 