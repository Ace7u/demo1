import torch
import torch.nn as nn
import torchaudio
from config import *

class PerturbationGenerator(nn.Module):
    def __init__(self):
        super().__init__()
        self.epsilon = EPSILON
        self.alpha = ALPHA
        
        # 时域卷积网络生成扰动
        self.conv_layers = nn.Sequential(
            nn.Conv1d(1, 16, kernel_size=3, padding=1),
            nn.ReLU(),
            nn.Conv1d(16, 32, kernel_size=3, padding=1),
            nn.ReLU(),
            nn.Conv1d(32, 16, kernel_size=3, padding=1),
            nn.ReLU(),
            nn.Conv1d(16, 1, kernel_size=3, padding=1),
            nn.Tanh()  # 限制扰动范围在[-1, 1]
        )
        
    def forward(self, x, masking_thresh=None):
        """
        生成对抗扰动
        Args:
            x: 输入音频 [batch_size, signal_length]
            masking_thresh: 掩蔽阈值 [batch_size, n_mels, time]
        Returns:
            perturbed_audio: 添加扰动后的音频
            perturbation: 生成的扰动
        """
        # 确保输入是二维的 [batch_size, signal_length]
        if x.dim() == 1:
            x = x.unsqueeze(0)
            
        # 添加通道维度
        x_reshape = x.unsqueeze(1)
        
        # 生成初始扰动
        perturbation = self.conv_layers(x_reshape)
        
        # 根据epsilon缩放扰动
        perturbation = self.epsilon * perturbation
        
        # 如果提供了掩蔽阈值，则应用心理声学约束
        if masking_thresh is not None:
            # 将扰动转换到频域
            perturbation_spec = torchaudio.transforms.MelSpectrogram(
                sample_rate=SAMPLE_RATE,
                n_fft=N_FFT,
                hop_length=HOP_LENGTH,
                win_length=WIN_LENGTH,
                n_mels=N_MELS
            )(perturbation.squeeze(1))
            
            # 转换为分贝刻度
            perturbation_db = 10 * torch.log10(torch.clamp(perturbation_spec, min=1e-10))
            
            # 应用掩蔽阈值约束
            mask = (perturbation_db > masking_thresh).float()
            scale_factor = torch.exp((masking_thresh - perturbation_db) / 20)
            scale_factor = torch.where(mask == 1, scale_factor, torch.ones_like(scale_factor))
            
            # 重新缩放扰动
            perturbation = perturbation * scale_factor.mean(dim=(1, 2)).unsqueeze(1).unsqueeze(2)
        
        # 生成对抗样本
        perturbed_audio = x + perturbation.squeeze(1)
        
        # 裁剪到有效范围
        perturbed_audio = torch.clamp(perturbed_audio, -1, 1)
        
        return perturbed_audio, perturbation.squeeze(1)
    
    def compute_loss(self, original_audio, perturbed_audio, original_features, perturbed_features, 
                    masking_thresh=None, vc_model=None):
        """
        计算完整的损失函数
        Args:
            original_audio: 原始音频
            perturbed_audio: 添加扰动后的音频
            original_features: 原始特征
            perturbed_features: 扰动后的特征
            masking_thresh: 掩蔽阈值
            vc_model: 语音转换模型（可选）
        Returns:
            total_loss: 总损失
            losses: 各项损失的字典
        """
        losses = {}
        
        # 1. 身份特征损失（最大化特征差异）
        identity_loss = -torch.nn.functional.mse_loss(original_features, perturbed_features)
        losses['identity'] = identity_loss.detach()
        
        # 2. 内容保持损失（最小化音频差异）
        content_loss = torch.nn.functional.mse_loss(original_audio, perturbed_audio)
        losses['content'] = content_loss.detach()
        
        # 3. 心理声学约束损失
        if masking_thresh is not None:
            perturbation = perturbed_audio - original_audio
            pert_spec = torchaudio.transforms.MelSpectrogram(
                sample_rate=SAMPLE_RATE,
                n_fft=N_FFT,
                hop_length=HOP_LENGTH,
                win_length=WIN_LENGTH,
                n_mels=N_MELS
            )(perturbation)
            pert_db = 10 * torch.log10(torch.clamp(pert_spec, min=1e-10))
            psycho_loss = torch.mean(torch.relu(pert_db - masking_thresh))
            losses['psychoacoustic'] = psycho_loss.detach()
        else:
            psycho_loss = torch.tensor(0.0).to(original_audio.device)
            losses['psychoacoustic'] = psycho_loss
            
        # 4. 语音转换防御损失（如果提供了VC模型）
        if vc_model is not None:
            with torch.no_grad():  # 避免VC模型的梯度计算
                converted_audio = vc_model.convert(perturbed_audio.detach())
                if converted_audio is not None:
                    vc_loss = vc_model.compute_conversion_loss(original_audio, converted_audio)
                    losses['vc_defense'] = vc_loss.detach()
                else:
                    vc_loss = torch.tensor(0.0).to(original_audio.device)
                    losses['vc_defense'] = vc_loss
        else:
            vc_loss = torch.tensor(0.0).to(original_audio.device)
            losses['vc_defense'] = vc_loss
            
        # 计算总损失（带权重）
        total_loss = (
            1.0 * identity_loss +  # 身份特征损失权重
            0.5 * content_loss +   # 内容保持损失权重
            0.3 * psycho_loss +    # 心理声学约束损失权重
            0.2 * vc_loss         # 语音转换防御损失权重
        )
        losses['total'] = total_loss.detach()
        
        return total_loss, losses
    
    def generate_perturbation(self, audio, feature_extractor, psychoacoustic_model=None, 
                            vc_model=None, num_iterations=100):
        """
        生成对抗扰动的主要函数
        Args:
            audio: 输入音频
            feature_extractor: 特征提取器模型
            psychoacoustic_model: 心理声学模型（可选）
            vc_model: 语音转换模型（可选）
            num_iterations: 迭代次数
        Returns:
            perturbed_audio: 添加扰动后的音频
            perturbation: 生成的扰动
            losses_history: 损失历史记录
        """
        audio = audio.clone().detach().requires_grad_(True)
        optimizer = torch.optim.Adam([audio], lr=self.alpha)
        losses_history = []
        best_loss = float('inf')
        best_result = None
        
        # 提取原始特征
        with torch.no_grad():
            original_features = feature_extractor(audio)
        
        for i in range(num_iterations):
            optimizer.zero_grad()
            
            # 计算掩蔽阈值（如果提供了心理声学模型）
            masking_thresh = None
            if psychoacoustic_model is not None:
                with torch.no_grad():
                    mel_spec = feature_extractor.mel_extractor(audio)
                    masking_thresh = psychoacoustic_model(mel_spec)
            
            # 生成扰动
            perturbed_audio, perturbation = self(audio, masking_thresh)
            
            # 提取扰动后的特征
            with torch.no_grad():
                perturbed_features = feature_extractor(perturbed_audio)
            
            # 计算损失
            loss, losses = self.compute_loss(
                audio, perturbed_audio,
                original_features, perturbed_features,
                masking_thresh, vc_model
            )
            
            # 记录损失
            losses_history.append(losses)
            
            # 保存最佳结果
            if loss.item() < best_loss:
                best_loss = loss.item()
                best_result = (perturbed_audio.detach(), perturbation.detach())
            
            # 反向传播
            loss.backward(retain_graph=True)
            
            # 更新
            optimizer.step()
            
            # 裁剪到有效范围
            with torch.no_grad():
                audio.clamp_(-1, 1)
                
        # 返回最佳结果
        if best_result is not None:
            return best_result[0], best_result[1], losses_history
        else:
            return perturbed_audio.detach(), perturbation.detach(), losses_history 