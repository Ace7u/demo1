import torch
import torch.nn as nn
import numpy as np
from config import *

class PsychoacousticModel(nn.Module):
    def __init__(self):
        super().__init__()
        self.bark_bands = BARK_BANDS
        self.quiet_thresh = QUIET_THRESH
        self.max_thresh = MAX_THRESH
        
        # 初始化Bark频率边界
        self.bark_freqs = self._init_bark_bands()
        
    def _init_bark_bands(self):
        """初始化Bark频带边界"""
        # Bark频率边界（Hz）
        bark_bounds = []
        for bark in range(self.bark_bands + 1):
            freq = 600 * np.sinh(bark / 6)
            bark_bounds.append(freq)
        return torch.tensor(bark_bounds)
    
    def _compute_spreading_function(self, bark_diff):
        """计算频谱扩散函数"""
        slope_left = -27.0  # dB/Bark for frequencies below masker
        slope_right = -24.0  # dB/Bark for frequencies above masker
        
        spreading = torch.zeros_like(bark_diff)
        spreading = torch.where(bark_diff < 0,
                              slope_left * bark_diff,
                              slope_right * bark_diff)
        return spreading
    
    def _absolute_threshold(self, freqs):
        """计算绝对听阈"""
        # 简化的绝对听阈模型
        f = freqs / 1000.0  # 转换为kHz
        thresh = 3.64 * (f ** -0.8) - 6.5 * torch.exp(-0.6 * (f - 3.3)**2) + 1e-3 * (f ** 4)
        return torch.clamp(thresh, min=self.quiet_thresh, max=self.max_thresh)
    
    def compute_masking_threshold(self, mel_spec):
        """
        计算掩蔽阈值
        Args:
            mel_spec: 梅尔频谱图 [batch_size, n_mels, time]
        Returns:
            masking_thresh: 掩蔽阈值 [batch_size, n_mels, time]
        """
        batch_size, n_mels, time_steps = mel_spec.shape
        
        # 将梅尔频谱转换为能量谱
        power_spec = torch.exp(mel_spec * 10)
        
        # 计算每个频带的中心频率
        mel_freqs = torch.linspace(0, SAMPLE_RATE/2, n_mels)
        
        # 计算绝对听阈
        abs_thresh = self._absolute_threshold(mel_freqs).unsqueeze(0).unsqueeze(-1)
        abs_thresh = abs_thresh.expand(batch_size, -1, time_steps)
        
        # 计算频带间的Bark距离
        bark_indices = 13 * torch.arctan(0.00076 * mel_freqs) + 3.5 * torch.arctan((mel_freqs / 7500) ** 2)
        bark_diff = bark_indices.unsqueeze(0) - bark_indices.unsqueeze(1)
        
        # 计算扩散函数
        spreading = self._compute_spreading_function(bark_diff)
        spreading = spreading.unsqueeze(0).expand(batch_size, -1, -1)
        
        # 计算掩蔽效应
        masking = torch.zeros_like(power_spec)
        for t in range(time_steps):
            power_frame = power_spec[..., t].unsqueeze(-1)  # [batch_size, n_mels, 1]
            spread_power = torch.matmul(spreading, power_frame).squeeze(-1)  # [batch_size, n_mels]
            masking[..., t] = spread_power
        
        # 合并掩蔽效应和绝对听阈
        masking_thresh = torch.maximum(masking, abs_thresh)
        
        # 转换回分贝刻度
        masking_thresh = 10 * torch.log10(torch.clamp(masking_thresh, min=1e-10))
        
        return masking_thresh
    
    def forward(self, mel_spec):
        return self.compute_masking_threshold(mel_spec) 