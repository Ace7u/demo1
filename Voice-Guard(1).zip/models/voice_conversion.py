import torch
import torch.nn as nn
import numpy as np
import logging

# 配置日志
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

class VoiceConversionModel(nn.Module):
    def __init__(self):
        super().__init__()
        self.device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
        logger.info(f"使用设备: {self.device}")
        
        # 初始化特征提取器（用于提取说话者身份特征）
        self.feature_extractor = nn.Sequential(
            nn.Conv1d(1, 32, kernel_size=3, stride=2, padding=1),
            nn.ReLU(),
            nn.Conv1d(32, 64, kernel_size=3, stride=2, padding=1),
            nn.ReLU(),
            nn.Conv1d(64, 128, kernel_size=3, stride=2, padding=1),
            nn.ReLU(),
            nn.AdaptiveAvgPool1d(1)
        ).to(self.device)
        
        # 初始化目标说话者特征
        self.target_features = None
        
        # 初始化音频合成器
        self.synth_net = nn.Sequential(
            nn.ConvTranspose1d(128, 64, kernel_size=4, stride=2, padding=1),
            nn.ReLU(),
            nn.ConvTranspose1d(64, 32, kernel_size=4, stride=2, padding=1),
            nn.ReLU(),
            nn.ConvTranspose1d(32, 1, kernel_size=4, stride=2, padding=1),
            nn.Tanh()
        ).to(self.device)
        
    def set_target_features(self, target_audio):
        """设置目标说话者特征"""
        with torch.no_grad():
            self.target_features = self.extract_features(target_audio)
        logger.info("目标说话者特征已更新")
        
    def extract_features(self, audio):
        """提取音频特征"""
        if len(audio.shape) == 1:
            audio = audio.unsqueeze(0).unsqueeze(0)
        elif len(audio.shape) == 2:
            audio = audio.unsqueeze(1)
            
        features = self.feature_extractor(audio)
        return features.squeeze(-1)
        
    def convert(self, audio):
        """执行语音转换"""
        try:
            # 确保输入维度正确
            if len(audio.shape) == 1:
                audio = audio.unsqueeze(0)
                
            # 提取特征
            features = self.extract_features(audio.unsqueeze(1))
            
            # 生成转换后的音频
            converted_features = features.unsqueeze(-1)
            converted_audio = self.synth_net(converted_features)
            
            # 调整输出音频长度
            target_length = audio.shape[-1]
            current_length = converted_audio.shape[-1]
            
            if current_length > target_length:
                converted_audio = converted_audio[..., :target_length]
            elif current_length < target_length:
                pad_length = target_length - current_length
                converted_audio = torch.nn.functional.pad(converted_audio, (0, pad_length))
                
            return converted_audio.squeeze(1)
            
        except Exception as e:
            logger.error(f"转换过程中出错: {str(e)}")
            return audio
        
    def compute_conversion_loss(self, original_audio, converted_audio):
        """计算转换损失（用于评估防御效果）"""
        if converted_audio is None:
            return torch.tensor(float('inf'))
            
        orig_features = self.extract_features(original_audio)
        conv_features = self.extract_features(converted_audio)
        
        return torch.mean((orig_features - conv_features) ** 2) 