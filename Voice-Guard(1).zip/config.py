import os

# 数据配置
DATA_DIR = os.path.join(os.path.dirname(__file__), 'data')
RESULTS_DIR = os.path.join(os.path.dirname(__file__), 'results')

# 音频参数
SAMPLE_RATE = 16000
HOP_LENGTH = 256
WIN_LENGTH = 1024
N_FFT = 1024
N_MELS = 80

# 模型参数
FEATURE_DIM = 256
BATCH_SIZE = 32
NUM_EPOCHS = 100
LEARNING_RATE = 0.001

# 对抗扰动参数
EPSILON = 0.1  # 扰动大小上限
ALPHA = 0.001  # 每步更新大小

# 心理声学模型参数
BARK_BANDS = 24
QUIET_THRESH = -60  # dB
MAX_THRESH = 60    # dB

# 评估参数
EVAL_METRICS = ['speaker_similarity', 'naturalness', 'content_preservation']

# 创建必要的目录
os.makedirs(DATA_DIR, exist_ok=True)
os.makedirs(RESULTS_DIR, exist_ok=True)
os.makedirs(os.path.join(RESULTS_DIR, 'figures'), exist_ok=True)
os.makedirs(os.path.join(RESULTS_DIR, 'audio'), exist_ok=True) 