import torch
import os
import numpy as np
import matplotlib.pyplot as plt
from models.feature_extractor import FeatureExtractor
from models.psychoacoustic import PsychoacousticModel
from models.perturbation_generator import PerturbationGenerator
from models.voice_conversion import VoiceConversionModel
from utils.audio import AudioProcessor
from utils.evaluation import Evaluator
from config import *

def run_ablation_study(audio_file):
    """
    运行消融实验
    Args:
        audio_file: 测试音频文件路径
    """
    # 初始化设备
    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    
    # 初始化模型和工具
    feature_extractor = FeatureExtractor().to(device)
    psychoacoustic_model = PsychoacousticModel().to(device)
    perturbation_generator = PerturbationGenerator().to(device)
    vc_model = VoiceConversionModel(model_type='adain')
    audio_processor = AudioProcessor()
    evaluator = Evaluator()
    
    # 加载音频
    waveform = audio_processor.load_audio(audio_file).to(device)
    
    # 实验配置
    experiments = {
        'Full Model': {
            'use_time_domain': True,
            'use_psychoacoustic': True,
            'use_vc_defense': True
        },
        'No Time Domain': {
            'use_time_domain': False,
            'use_psychoacoustic': True,
            'use_vc_defense': True
        },
        'No Psychoacoustic': {
            'use_time_domain': True,
            'use_psychoacoustic': False,
            'use_vc_defense': True
        },
        'No VC Defense': {
            'use_time_domain': True,
            'use_psychoacoustic': True,
            'use_vc_defense': False
        }
    }
    
    results = {}
    for exp_name, config in experiments.items():
        print(f"\n运行实验: {exp_name}")
        
        # 根据配置设置模型参数
        if not config['use_time_domain']:
            # 在频域生成扰动
            perturbation_generator.conv_layers = nn.Sequential(
                nn.Linear(N_MELS * (N_FFT // HOP_LENGTH + 1), 512),
                nn.ReLU(),
                nn.Linear(512, waveform.shape[-1])
            )
            
        # 生成对抗扰动
        perturbed_audio, perturbation, losses = perturbation_generator.generate_perturbation(
            waveform,
            feature_extractor,
            psychoacoustic_model if config['use_psychoacoustic'] else None,
            vc_model if config['use_vc_defense'] else None
        )
        
        # 提取特征
        original_features = feature_extractor(waveform)
        perturbed_features = feature_extractor(perturbed_audio)
        
        # 评估结果
        metrics = evaluator.evaluate(
            waveform,
            perturbed_audio,
            original_features,
            perturbed_features
        )
        
        # 保存结果
        results[exp_name] = {
            'metrics': metrics,
            'losses': losses[-1] if losses else None
        }
        
        # 保存音频
        output_dir = os.path.join(RESULTS_DIR, 'ablation', exp_name)
        os.makedirs(output_dir, exist_ok=True)
        
        audio_processor.save_audio(
            perturbed_audio,
            os.path.join(output_dir, 'perturbed_audio.wav')
        )
        audio_processor.save_audio(
            perturbation,
            os.path.join(output_dir, 'perturbation.wav')
        )
        
    # 绘制对比图
    plot_ablation_results(results)
    
def plot_ablation_results(results):
    """绘制消融实验结果对比图"""
    metrics = ['Speaker Similarity', 'Naturalness', 'Content Preservation']
    exp_names = list(results.keys())
    
    # 设置图表样式
    plt.style.use('classic')
    plt.figure(figsize=(15, 6))
    
    # 设置柱状图位置
    x = np.arange(len(metrics))
    width = 0.2
    multiplier = 0
    
    # 绘制每个实验的结果
    for exp_name, result in results.items():
        offset = width * multiplier
        rects = plt.bar(x + offset, 
                       [result['metrics'][m] for m in metrics],
                       width, 
                       label=exp_name)
        multiplier += 1
    
    # 设置图表属性
    plt.ylabel('Score')
    plt.title('Ablation Study Results')
    plt.xticks(x + width * (len(results) - 1) / 2, metrics, rotation=15)
    plt.legend(loc='upper left', bbox_to_anchor=(1, 1))
    plt.grid(True, axis='y', linestyle='--', alpha=0.3)
    
    # 调整布局
    plt.tight_layout()
    
    # 保存图表
    plt.savefig(os.path.join(RESULTS_DIR, 'ablation', 'comparison.png'),
                dpi=300, bbox_inches='tight', facecolor='white')
    plt.close()

if __name__ == '__main__':
    # 运行消融实验
    test_audio_dir = os.path.join(DATA_DIR, 'test_audio')
    if not os.path.exists(test_audio_dir):
        print(f"测试音频目录不存在: {test_audio_dir}")
        exit(1)
        
    audio_files = [f for f in os.listdir(test_audio_dir) if f.endswith('.wav')]
    if not audio_files:
        print("未找到测试音频文件")
        exit(1)
        
    # 为每个测试音频运行消融实验
    for audio_file in audio_files:
        print(f"\n处理音频: {audio_file}")
        run_ablation_study(os.path.join(test_audio_dir, audio_file)) 