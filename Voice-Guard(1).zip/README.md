# Voice Guard

基于论文 "Voice Guard: Protecting Voice Privacy with Strong and Imperceptible Adversarial Perturbation in the Time Domain" 的实现。

## 项目简介

Voice Guard 是一个语音隐私保护系统，通过在时域添加不可感知的对抗扰动来防御零样本语音转换攻击。本项目实现了论文中提出的主要功能：

- 时域对抗扰动生成
- 心理声学模型约束
- 说话者特征提取
- 防御效果评估

## 系统要求

- Python 3.9+
- PyTorch 2.0+
- torchaudio
- numpy
- matplotlib
- seaborn
- scipy
- pystoi
- soundfile
- CUDA（可选，用于GPU加速）

## 安装说明

1. 克隆仓库：
```bash
git clone https://github.com/your-username/Voice-Guard.git
cd Voice-Guard
```

2. 安装依赖：
```bash
pip install -r requirements.txt
```

## 项目结构

```
Voice-Guard/
├── data/                      # 数据目录
│   └── test_audio/           # 测试音频文件
├── models/                    # 模型实现
│   ├── feature_extractor.py  # 特征提取器
│   ├── psychoacoustic.py     # 心理声学模型
│   ├── perturbation_generator.py  # 对抗扰动生成器
│   └── voice_conversion.py   # 语音转换模型
├── utils/                    # 工具函数
│   ├── audio.py             # 音频处理工具
│   └── evaluation.py        # 评估工具
├── results/                  # 输出结果目录
├── config.py                # 配置文件
├── main.py                  # 主程序
└── requirements.txt         # 依赖列表
```

## 使用方法

1. 准备数据：
   - 将要保护的音频文件（WAV格式）放在 `data/test_audio/` 目录下

2. 运行程序：
```bash
python main.py
```

3. 查看结果：
   结果将保存在 `results/` 目录下，每个音频文件会生成一个独立的子目录，包含：
   - `perturbed_audio.wav`: 添加对抗扰动后的音频
   - `perturbation.wav`: 生成的对抗扰动信号

## 评估指标

系统使用以下指标评估防御效果：

1. **说话者相似度** (Speaker Similarity)
   - 衡量处理后音频与原始音频的声音特征相似度
   - 使用余弦相似度计算
   - 范围：0-1，越高越好

2. **自然度** (Naturalness)
   - 评估处理后音频的自然程度
   - 使用STOI (Short-Time Objective Intelligibility) 指标
   - 范围：0-1，越高越好

3. **内容保持度** (Content Preservation)
   - 衡量处理后音频在保持语音内容方面的效果
   - 使用特征相关性计算
   - 范围：0-1，越高越好

4. **Mel倒谱失真** (MCD)
   - 评估音频失真程度
   - 值越小表示失真越小

## 实现细节

1. **特征提取**
   - 使用多层卷积神经网络提取说话者身份特征
   - 支持批处理和自适应池化

2. **对抗扰动生成**
   - 在时域直接生成对抗扰动
   - 使用心理声学模型约束扰动的不可感知性
   - 支持带/不带心理声学模型的对比实验

3. **音频处理**
   - 支持多种音频格式加载
   - 自动进行采样率转换
   - 处理单声道/立体声转换
   - 音频分段处理和合并

## 注意事项

1. 确保输入音频的采样率符合系统要求（默认16kHz）
2. 音频文件应为WAV格式
3. GPU加速需要安装CUDA支持的PyTorch版本
4. 处理长音频文件时可能需要较大的内存空间

## 参考文献

[1] Voice Guard: Protecting Voice Privacy with Strong and Imperceptible Adversarial Perturbation in the Time Domain