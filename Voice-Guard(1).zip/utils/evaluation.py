import torch
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from scipy.stats import pearsonr
from pystoi import stoi
import pandas as pd
from config import *
import os

class Evaluator:
    def __init__(self):
        self.metrics = {}
        self.mcd_thresholds = np.linspace(0, 10, 21)  # 0到10的MCD阈值
        
    def compute_speaker_similarity(self, original_features, perturbed_features):
        """计算说话者相似度"""
        original_features = original_features.detach().cpu().numpy()
        perturbed_features = perturbed_features.detach().cpu().numpy()
        
        similarities = []
        for orig, pert in zip(original_features, perturbed_features):
            # 使用余弦相似度
            similarity = np.dot(orig, pert) / (np.linalg.norm(orig) * np.linalg.norm(pert))
            similarities.append(similarity)
            
        return np.mean(similarities)
    
    def compute_naturalness(self, original_audio, perturbed_audio):
        """计算语音自然度（使用STOI评分）"""
        original_audio = original_audio.detach().cpu().numpy()
        perturbed_audio = perturbed_audio.detach().cpu().numpy()
        
        scores = []
        for orig, pert in zip(original_audio, perturbed_audio):
            try:
                # STOI需要输入信号的采样率为10000Hz或以上
                score = stoi(orig, pert, SAMPLE_RATE, extended=False)
                scores.append(score)
            except:
                continue
                
        return np.mean(scores) if scores else 0.0
    
    def compute_content_preservation(self, original_features, perturbed_features):
        """计算内容保持度"""
        original_features = original_features.detach().cpu().numpy()
        perturbed_features = perturbed_features.detach().cpu().numpy()
        
        correlations = []
        for orig, pert in zip(original_features, perturbed_features):
            correlation, _ = pearsonr(orig, pert)
            correlations.append(correlation)
            
        return np.mean(correlations)
    
    def compute_mcd(self, original_features, perturbed_features):
        """计算Mel倒谱失真(MCD)"""
        original_features = original_features.detach().cpu().numpy()
        perturbed_features = perturbed_features.detach().cpu().numpy()
        
        mcd_values = []
        for orig, pert in zip(original_features, perturbed_features):
            mcd = np.sqrt(np.mean((orig - pert) ** 2)) * 10 / np.log(10)
            mcd_values.append(mcd)
            
        return np.mean(mcd_values)
    
    def compute_defense_success_rate(self, original_features, perturbed_features, converted_features):
        """计算防御成功率"""
        mcd_orig_pert = self.compute_mcd(original_features, perturbed_features)
        mcd_orig_conv = self.compute_mcd(original_features, converted_features)
        
        return 1.0 if mcd_orig_pert < mcd_orig_conv else 0.0
    
    def evaluate(self, original_audio, perturbed_audio, original_features, perturbed_features, converted_features=None):
        """评估所有指标"""
        metrics = {}
        
        # 计算基本指标
        metrics['Speaker Similarity'] = self.compute_speaker_similarity(original_features, perturbed_features)
        metrics['Naturalness'] = self.compute_naturalness(original_audio, perturbed_audio)
        metrics['Content Preservation'] = self.compute_content_preservation(original_features, perturbed_features)
        metrics['MCD'] = self.compute_mcd(original_features, perturbed_features)
        
        # 如果提供了转换后的特征，计算防御成功率
        if converted_features is not None:
            metrics['Defense Success Rate'] = self.compute_defense_success_rate(
                original_features, perturbed_features, converted_features)
        
        return metrics
    
    def plot_defense_success_rate_trend(self, results_dict, output_dir):
        """绘制防御成功率随MCD失真的变化趋势"""
        plt.style.use('seaborn')
        plt.figure(figsize=(12, 8))
        
        colors = ['#2ecc71', '#e74c3c']  # 绿色和红色
        markers = ['o', 's']
        
        for (method, results), color, marker in zip(results_dict.items(), colors, markers):
            success_rates = []
            for threshold in self.mcd_thresholds:
                rate = np.mean([r > threshold for r in results['mcd_values']])
                success_rates.append(rate)
            
            plt.plot(self.mcd_thresholds, success_rates, 
                    label=method, 
                    color=color,
                    marker=marker,
                    markersize=8,
                    linewidth=2.5)
        
        plt.xlabel('MCD Distortion', fontsize=12)
        plt.ylabel('Defense Success Rate', fontsize=12)
        plt.title('Defense Success Rate vs. MCD Distortion', fontsize=14, pad=20)
        plt.grid(True, linestyle='--', alpha=0.7)
        plt.legend(fontsize=10, loc='upper right')
        
        # 设置坐标轴范围和刻度
        plt.xlim(0, 10)
        plt.ylim(0, 1.05)
        plt.xticks(fontsize=10)
        plt.yticks(fontsize=10)
        
        # 添加网格和边框
        plt.grid(True, linestyle='--', alpha=0.3)
        for spine in plt.gca().spines.values():
            spine.set_visible(True)
            spine.set_linewidth(1.5)
        
        plt.tight_layout()
        plt.savefig(os.path.join(output_dir, 'defense_success_rate_trend.png'),
                   dpi=300,
                   bbox_inches='tight',
                   facecolor='white')
        plt.close()
        
    def plot_feature_variation_trend(self, results_dict, output_dir):
        """绘制语音特征随MCD失真的变化趋势"""
        plt.style.use('seaborn')
        plt.figure(figsize=(14, 8))
        
        metrics = ['Speaker Similarity', 'Naturalness', 'Content Preservation']
        colors = ['#3498db', '#e67e22', '#9b59b6']  # 蓝色、橙色和紫色
        markers = ['o', 's', '^']
        
        for method, results in results_dict.items():
            for metric, color, marker in zip(metrics, colors, markers):
                # 防御音频的性能
                plt.plot(self.mcd_thresholds, results[f'{metric}_defended'],
                        color=color,
                        label=f'{method} (Defended) - {metric}',
                        linestyle='-',
                        marker=marker,
                        markersize=8,
                        linewidth=2.5)
                
                # 转换音频的性能
                plt.plot(self.mcd_thresholds, results[f'{metric}_converted'],
                        color=color,
                        label=f'{method} (Converted) - {metric}',
                        linestyle='--',
                        marker=marker,
                        markersize=8,
                        linewidth=2.5)
        
        plt.xlabel('MCD Distortion', fontsize=12)
        plt.ylabel('Metric Value', fontsize=12)
        plt.title('Speech Feature Variation with MCD Distortion', fontsize=14, pad=20)
        plt.grid(True, linestyle='--', alpha=0.3)
        
        # 设置图例
        plt.legend(bbox_to_anchor=(1.05, 1),
                  loc='upper left',
                  fontsize=10,
                  frameon=True,
                  edgecolor='black')
        
        # 设置坐标轴范围和刻度
        plt.xlim(0, 10)
        plt.ylim(0, 1.05)
        plt.xticks(fontsize=10)
        plt.yticks(fontsize=10)
        
        # 添加网格和边框
        plt.grid(True, linestyle='--', alpha=0.3)
        for spine in plt.gca().spines.values():
            spine.set_visible(True)
            spine.set_linewidth(1.5)
        
        plt.tight_layout()
        plt.savefig(os.path.join(output_dir, 'feature_variation_trend.png'),
                   dpi=300,
                   bbox_inches='tight',
                   facecolor='white')
        plt.close()
        
    def save_results(self, output_dir):
        """保存评估结果"""
        results_file = os.path.join(output_dir, 'evaluation_results.txt')
        with open(results_file, 'w', encoding='utf-8') as f:
            for metric, value in self.metrics.items():
                f.write(f'{metric}: {value:.4f}\n')
                
    def plot_results(self, output_dir):
        """绘制评估结果柱状图"""
        plt.style.use('seaborn')
        plt.figure(figsize=(10, 6))
        
        metrics = list(self.metrics.keys())
        values = list(self.metrics.values())
        
        colors = ['#3498db', '#2ecc71', '#e74c3c', '#f1c40f', '#9b59b6']
        plt.bar(metrics, values, color=colors, width=0.6)
        plt.ylim(0, 1.0)
        plt.grid(True, axis='y', linestyle='--', alpha=0.3)
        
        plt.ylabel('Score', fontsize=12)
        plt.title('Evaluation Results', fontsize=14, pad=20)
        
        # 旋转x轴标签以防止重叠
        plt.xticks(rotation=15, fontsize=10)
        plt.yticks(fontsize=10)
        
        # 在柱子上显示具体数值
        for i, v in enumerate(values):
            plt.text(i, v + 0.01, f'{v:.4f}', ha='center', fontsize=10)
        
        # 添加网格和边框
        plt.grid(True, linestyle='--', alpha=0.3)
        for spine in plt.gca().spines.values():
            spine.set_visible(True)
            spine.set_linewidth(1.5)
            
        plt.tight_layout()
        plt.savefig(os.path.join(output_dir, 'evaluation_results.png'),
                   dpi=300,
                   bbox_inches='tight',
                   facecolor='white') 