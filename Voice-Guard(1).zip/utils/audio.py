import torch
import torchaudio
import numpy as np
import os
from config import *

class AudioProcessor:
    def __init__(self):
        self.sample_rate = SAMPLE_RATE
        
    def load_audio(self, file_path):
        """加载音频文件"""
        try:
            # 检查文件是否存在
            if not os.path.exists(file_path):
                raise FileNotFoundError(f"音频文件不存在: {file_path}")
                
            # 尝试加载音频
            try:
                waveform, sr = torchaudio.load(file_path)
            except:
                # 如果torchaudio加载失败，尝试使用soundfile
                import soundfile as sf
                waveform, sr = sf.read(file_path)
                waveform = torch.FloatTensor(waveform)
                if len(waveform.shape) == 1:
                    waveform = waveform.unsqueeze(0)
                else:
                    waveform = waveform.t()
            
            # 转换为单声道
            if waveform.shape[0] > 1:
                waveform = torch.mean(waveform, dim=0, keepdim=True)
                
            # 重采样到目标采样率
            if sr != self.sample_rate:
                resampler = torchaudio.transforms.Resample(sr, self.sample_rate)
                waveform = resampler(waveform)
                
            # 归一化
            waveform = waveform / (torch.max(torch.abs(waveform)) + 1e-8)
            
            return waveform
            
        except Exception as e:
            print(f"加载音频文件 {file_path} 时出错: {str(e)}")
            raise
    
    def save_audio(self, waveform, file_path):
        """保存音频文件"""
        # 确保目录存在
        os.makedirs(os.path.dirname(file_path), exist_ok=True)
        
        # 分离梯度
        waveform = waveform.detach()
        
        # 确保waveform是2D张量 [channels, samples]
        if waveform.dim() == 1:
            waveform = waveform.unsqueeze(0)
        elif waveform.dim() == 3:
            waveform = waveform.squeeze(0)  # 移除batch维度
            
        # 确保是单声道
        if waveform.shape[0] > 1:
            waveform = waveform.mean(dim=0, keepdim=True)
            
        # 保存音频
        torchaudio.save(file_path, waveform.cpu(), self.sample_rate)
    
    def apply_perturbation(self, waveform, perturbation):
        """应用扰动到音频"""
        # 确保维度匹配
        if waveform.dim() == 1:
            waveform = waveform.unsqueeze(0)
        if perturbation.dim() == 1:
            perturbation = perturbation.unsqueeze(0)
            
        # 应用扰动
        perturbed = waveform + perturbation
        
        # 裁剪到有效范围
        perturbed = torch.clamp(perturbed, -1, 1)
        
        return perturbed
    
    def segment_audio(self, waveform, segment_length):
        """将音频分段"""
        # 如果音频长度小于段长，则进行填充
        if waveform.shape[-1] < segment_length:
            pad_length = segment_length - waveform.shape[-1]
            waveform = torch.nn.functional.pad(waveform, (0, pad_length))
            return waveform.unsqueeze(0)
        
        # 分段
        segments = []
        for i in range(0, waveform.shape[-1], segment_length):
            segment = waveform[..., i:i+segment_length]
            if segment.shape[-1] == segment_length:
                segments.append(segment)
                
        return torch.stack(segments)
    
    def combine_segments(self, segments, overlap=0.1):
        """合并音频段"""
        if segments.shape[0] == 1:
            return segments.squeeze(0)
            
        # 计算重叠样本数
        overlap_samples = int(segments.shape[-1] * overlap)
        
        # 使用交叉淡入淡出合并段
        combined = segments[0]
        for i in range(1, len(segments)):
            # 创建淡入淡出窗口
            fade_in = torch.linspace(0, 1, overlap_samples)
            fade_out = torch.linspace(1, 0, overlap_samples)
            
            # 应用交叉淡入淡出
            overlap_region = combined[-overlap_samples:] * fade_out + \
                           segments[i][:overlap_samples] * fade_in
            
            # 合并段
            combined = torch.cat([combined[:-overlap_samples], 
                                overlap_region,
                                segments[i][overlap_samples:]])
            
        return combined
    
    def preprocess_batch(self, file_paths, segment_length=None):
        """批量预处理音频文件"""
        waveforms = []
        for path in file_paths:
            waveform = self.load_audio(path)
            if segment_length is not None:
                waveform = self.segment_audio(waveform.squeeze(0), segment_length)
            waveforms.append(waveform)
            
        # 将所有波形填充到相同长度
        max_length = max(w.shape[-1] for w in waveforms)
        padded_waveforms = []
        for waveform in waveforms:
            if waveform.shape[-1] < max_length:
                pad_length = max_length - waveform.shape[-1]
                padded = torch.nn.functional.pad(waveform, (0, pad_length))
                padded_waveforms.append(padded)
            else:
                padded_waveforms.append(waveform)
                
        return torch.stack(padded_waveforms) 